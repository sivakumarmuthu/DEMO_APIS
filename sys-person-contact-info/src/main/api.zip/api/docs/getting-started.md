Repository: sys-contact-info-api
API Name: sys-contact-info-api
API Layer: SYSTEM
API Description: This system API is used to create,read,update and delete 

Header Info:
----------------
applicationId:DEMO-BANK
messageDateTimeStamp:2007-10-01T14:20:33
messageId:1000


Requirements:
--------------------
JDK 1.8 Maven 3
Install
To build and run tests:
mvn clean install
Conclusion:
This API need to be installed in mule api-gateway runtime.